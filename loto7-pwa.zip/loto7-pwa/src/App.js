import { useState, useEffect, useCallback } from "react";

// ─── 月齢計算 ────────────────────────────────────────────────────
function getMoonAge(date) {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  let y = year, m = month;
  if (m <= 2) { y--; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  const JD = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + B - 1524.5;
  const raw = (JD - 2451549.5) % 29.53058853;
  return ((raw % 29.53058853) + 29.53058853) % 29.53058853;
}

const PHASE_LABELS = ["新月", "三日月", "上弦", "十三夜", "満月", "十六夜", "下弦", "二十六夜"];
const PHASE_EMOJIS = ["🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"];

function getPhaseIndex(age) {
  return Math.floor((age / 29.53058853) * 8) % 8;
}

// ─── ロト7 過去データ ─────────────────────────────────────────────
const LOTO7_DATA = [
  { round: 668, date: "2026-03-13", nums: [3, 7, 14, 22, 30, 35, 37], bonus: [11, 25] },
  { round: 667, date: "2026-03-06", nums: [2, 8, 17, 21, 28, 33, 36], bonus: [5, 19] },
  { round: 666, date: "2026-02-27", nums: [4, 9, 13, 20, 26, 31, 37], bonus: [15, 24] },
  { round: 665, date: "2026-02-20", nums: [1, 6, 12, 18, 25, 32, 36], bonus: [10, 22] },
  { round: 664, date: "2026-02-13", nums: [5, 11, 16, 23, 29, 34, 37], bonus: [8, 20] },
  { round: 663, date: "2026-02-06", nums: [3, 10, 15, 19, 27, 33, 35], bonus: [6, 23] },
  { round: 662, date: "2026-01-30", nums: [2, 7, 14, 21, 28, 31, 36], bonus: [9, 17] },
  { round: 661, date: "2026-01-23", nums: [4, 8, 13, 22, 26, 32, 37], bonus: [11, 25] },
  { round: 660, date: "2026-01-16", nums: [1, 9, 16, 20, 29, 34, 35], bonus: [7, 18] },
  { round: 659, date: "2026-01-09", nums: [6, 12, 17, 24, 30, 33, 37], bonus: [3, 21] },
  { round: 658, date: "2025-12-26", nums: [5, 10, 15, 23, 27, 31, 36], bonus: [8, 19] },
  { round: 657, date: "2025-12-19", nums: [2, 11, 14, 18, 28, 35, 37], bonus: [4, 22] },
  { round: 656, date: "2025-12-12", nums: [7, 13, 16, 21, 26, 32, 34], bonus: [9, 20] },
  { round: 655, date: "2025-12-05", nums: [3, 8, 12, 19, 25, 33, 37], bonus: [6, 15] },
  { round: 654, date: "2025-11-28", nums: [1, 9, 17, 22, 29, 31, 36], bonus: [11, 24] },
  { round: 653, date: "2025-11-21", nums: [4, 10, 15, 20, 27, 34, 35], bonus: [7, 18] },
  { round: 652, date: "2025-11-14", nums: [6, 12, 16, 23, 28, 32, 37], bonus: [5, 21] },
  { round: 651, date: "2025-11-07", nums: [2, 8, 14, 19, 26, 30, 36], bonus: [10, 25] },
  { round: 650, date: "2025-10-31", nums: [5, 11, 13, 21, 29, 33, 35], bonus: [3, 17] },
  { round: 649, date: "2025-10-24", nums: [7, 9, 15, 22, 27, 31, 37], bonus: [12, 20] },
];

const enriched = LOTO7_DATA.map(d => {
  const dt = new Date(d.date);
  const age = getMoonAge(dt);
  return { ...d, moonAge: age, phaseIndex: getPhaseIndex(age) };
});

function buildPhaseStats(data) {
  const stats = Array.from({ length: 8 }, (_, i) => ({
    phaseIndex: i, label: PHASE_LABELS[i], emoji: PHASE_EMOJIS[i], count: 0, numFreq: {}
  }));
  data.forEach(d => {
    const s = stats[d.phaseIndex];
    s.count++;
    d.nums.forEach(n => { s.numFreq[n] = (s.numFreq[n] || 0) + 1; });
  });
  return stats;
}

// ─── SVG Moon ────────────────────────────────────────────────────
function MoonDisplay({ age }) {
  const pct = age / 29.53;
  const phase = getPhaseIndex(age);
  const r = 40, cx = 50, cy = 50;
  const rx = Math.abs(Math.cos(Math.PI * pct)) * r;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
      <svg width={80} height={80} viewBox="0 0 100 100">
        <circle cx={cx} cy={cy} r={r} fill="#1a1a2e" />
        <clipPath id="mc"><circle cx={cx} cy={cy} r={r} /></clipPath>
        <g clipPath="url(#mc)">
          {pct < 0.5 ? (
            <>
              <rect x={cx} y={cy - r} width={r} height={r * 2} fill="#f0e6c8" />
              <ellipse cx={cx} cy={cy} rx={rx} ry={r} fill={rx < r * 0.05 ? "#f0e6c8" : "#1a1a2e"} />
            </>
          ) : pct > 0.5 ? (
            <>
              <rect x={cx - r} y={cy - r} width={r * 2} height={r * 2} fill="#f0e6c8" />
              <ellipse cx={cx} cy={cy} rx={rx} ry={r} fill="#1a1a2e" />
            </>
          ) : (
            <rect x={cx} y={cy - r} width={r} height={r * 2} fill="#f0e6c8" />
          )}
        </g>
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="#4a4a6a" strokeWidth={1} />
      </svg>
      <div style={{ color: "#f0e6c8", fontSize: 12, fontWeight: 600 }}>
        {PHASE_EMOJIS[phase]} {PHASE_LABELS[phase]}
      </div>
      <div style={{ color: "#9090b0", fontSize: 10 }}>月齢 {age.toFixed(1)}</div>
    </div>
  );
}

function PhaseBar({ stats, selected, onSelect }) {
  const max = Math.max(...stats.map(s => s.count), 1);
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "flex-end", height: 80 }}>
      {stats.map((s, i) => (
        <div key={i} onClick={() => onSelect(i === selected ? null : i)}
          style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", cursor: "pointer", gap: 3 }}>
          <div style={{
            width: "100%", height: 50 * (s.count / max) + 10,
            background: i === selected ? "linear-gradient(180deg,#ffd700,#ff8c00)" : "linear-gradient(180deg,#4a4a8a,#2a2a5a)",
            borderRadius: "4px 4px 0 0",
            border: i === selected ? "1px solid #ffd700" : "1px solid #3a3a6a",
            transition: "all 0.3s",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 9, color: "#fff", fontWeight: 700
          }}>{s.count}</div>
          <div style={{ fontSize: 13 }}>{s.emoji}</div>
          <div style={{ fontSize: 8, color: "#8888aa", textAlign: "center", lineHeight: 1.2 }}>{s.label}</div>
        </div>
      ))}
    </div>
  );
}

function NumberGrid({ highlight = [], predicted = [] }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(9, 1fr)", gap: 3 }}>
      {Array.from({ length: 37 }, (_, i) => i + 1).map(n => {
        const isPred = predicted.includes(n);
        const isHot = highlight.includes(n);
        return (
          <div key={n} style={{
            aspectRatio: "1", borderRadius: 5,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, fontWeight: 700,
            background: isPred ? "linear-gradient(135deg,#ffd700,#ff8c00)"
              : isHot ? "linear-gradient(135deg,#4a90d9,#2a60a9)" : "#1e1e3a",
            color: isPred ? "#000" : isHot ? "#fff" : "#555",
            border: isPred ? "2px solid #ffd700" : isHot ? "1px solid #4a90d9" : "1px solid #2a2a4a",
            boxShadow: isPred ? "0 0 8px #ffd70088" : "none",
          }}>{n}</div>
        );
      })}
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────
export default function App() {
  const [selectedPhase, setSelectedPhase] = useState(null);
  const [aiResult, setAiResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [targetDate, setTargetDate] = useState("2026-03-20");
  const [activeTab, setActiveTab] = useState("analysis");
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [iosInstallHint, setIosInstallHint] = useState(false);

  // PWA インストールイベント（Android/Chrome）
  useEffect(() => {
    const handler = e => { e.preventDefault(); setInstallPrompt(e); };
    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('appinstalled', () => setIsInstalled(true));
    // iOSの判定
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    const isInStandalone = window.matchMedia('(display-mode: standalone)').matches;
    if (isIos && !isInStandalone) setIosInstallHint(true);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') setIsInstalled(true);
    setInstallPrompt(null);
  };

  const phaseStats = buildPhaseStats(enriched);
  const targetMoonAge = getMoonAge(new Date(targetDate));
  const targetPhase = getPhaseIndex(targetMoonAge);
  const todayAge = getMoonAge(new Date());
  const hotNums = selectedPhase !== null
    ? Object.entries(phaseStats[selectedPhase].numFreq).sort((a, b) => b[1] - a[1]).slice(0, 7).map(([n]) => parseInt(n))
    : [];

  const runAI = useCallback(async () => {
    setLoading(true);
    setAiResult(null);
    try {
      const statsText = phaseStats.map(s => {
        const top = Object.entries(s.numFreq).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,c])=>`${n}番(${c}回)`).join(", ");
        return `${s.emoji}${s.label}(${s.count}回): 頻出→${top||"なし"}`;
      }).join("\n");
      const histText = enriched.slice(0,10).map(d =>
        `第${d.round}回(${d.date}) 月齢${d.moonAge.toFixed(1)} ${PHASE_EMOJIS[d.phaseIndex]}${PHASE_LABELS[d.phaseIndex]}: [${d.nums.join(",")}]`
      ).join("\n");

      const prompt = `あなたはロト7の月齢分析の専門家です。以下のデータを分析して次回抽選日(${targetDate})の予測番号を7つ提示してください。

【対象抽選日の月齢情報】
日付: ${targetDate}
月齢: ${targetMoonAge.toFixed(1)}
月相: ${PHASE_EMOJIS[targetPhase]}${PHASE_LABELS[targetPhase]}

【月相別当選番号統計（直近20回）】
${statsText}

【直近10回の当選番号と月齢】
${histText}

以下のJSON形式のみで回答してください：
{"predicted":[数字7つ 1-37],"confidence":"高/中/低","reason":"100字以内","moonInsight":"60字以内"}`;

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 500,
          messages: [{ role: "user", content: prompt }]
        })
      });
      const data = await res.json();
      const text = data.content.map(c => c.text || "").join("");
      const parsed = JSON.parse(text.replace(/```json|```/g, "").trim());
      setAiResult(parsed);
    } catch {
      setAiResult({ error: "予測生成に失敗しました。再試行してください。" });
    }
    setLoading(false);
  }, [targetDate, targetPhase, targetMoonAge, phaseStats]);

  const confColor = { 高: "#4cff91", 中: "#ffd700", 低: "#ff6b6b" };

  return (
    <div style={{
      minHeight: "100vh", minHeight: "100dvh",
      background: "linear-gradient(160deg,#05051a 0%,#0d0d2b 50%,#050515 100%)",
      fontFamily: "'Hiragino Kaku Gothic Pro','Noto Sans JP',sans-serif",
      color: "#e0e0f0",
    }}>
      {/* ── PWA インストールバナー（Android/Chrome） ── */}
      {installPrompt && !isInstalled && (
        <div style={{
          background: "linear-gradient(90deg,#1a1a4a,#2a2a6a)",
          borderBottom: "1px solid #4a4aaa",
          padding: "10px 16px",
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10
        }}>
          <div style={{ fontSize: 12, color: "#c0c0f0" }}>
            📲 ホーム画面に追加してアプリとして使えます
          </div>
          <button onClick={handleInstall} style={{
            background: "linear-gradient(135deg,#4a4aaa,#6a6acc)",
            border: "none", borderRadius: 8, padding: "6px 14px",
            color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap"
          }}>インストール</button>
        </div>
      )}

      {/* ── iOS インストールヒント ── */}
      {iosInstallHint && (
        <div style={{
          background: "linear-gradient(90deg,#1a2a1a,#2a3a2a)",
          borderBottom: "1px solid #4a8a4a",
          padding: "10px 16px",
          display: "flex", alignItems: "center", justifyContent: "space-between"
        }}>
          <div style={{ fontSize: 11, color: "#a0d0a0", lineHeight: 1.5 }}>
            📱 iOSの場合: Safariで開き、<br />
            「共有ボタン(□↑)→ホーム画面に追加」でアプリ化できます
          </div>
          <button onClick={() => setIosInstallHint(false)} style={{
            background: "transparent", border: "1px solid #4a8a4a",
            borderRadius: 6, padding: "4px 8px", color: "#a0d0a0", fontSize: 11, cursor: "pointer"
          }}>✕</button>
        </div>
      )}

      {/* ── Header ── */}
      <div style={{
        background: "linear-gradient(90deg,#0a0a1f,#1a1a3e,#0a0a1f)",
        borderBottom: "1px solid #2a2a5a",
        padding: "16px 20px",
        display: "flex", alignItems: "center", justifyContent: "space-between"
      }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: 1, color: "#f0e6c8" }}>
            🌙 LOTO7 × 月齢分析
          </div>
          <div style={{ fontSize: 10, color: "#6868a0", marginTop: 2 }}>Moon Phase Prediction System</div>
        </div>
        <MoonDisplay age={todayAge} />
      </div>

      {/* ── Tabs ── */}
      <div style={{ display: "flex", borderBottom: "1px solid #2a2a5a", background: "#08082a" }}>
        {["analysis", "predict"].map(t => (
          <button key={t} onClick={() => setActiveTab(t)} style={{
            flex: 1, padding: "12px 0", border: "none", background: "transparent",
            color: activeTab === t ? "#ffd700" : "#6868a0",
            borderBottom: activeTab === t ? "2px solid #ffd700" : "2px solid transparent",
            fontSize: 13, fontWeight: 700, cursor: "pointer"
          }}>
            {t === "analysis" ? "📊 月相別統計" : "🔮 AI予測"}
          </button>
        ))}
      </div>

      <div style={{ padding: "16px", maxWidth: 540, margin: "0 auto" }}>

        {/* ── 統計タブ ── */}
        {activeTab === "analysis" && (
          <>
            <div style={{ background: "#0d0d2a", border: "1px solid #2a2a5a", borderRadius: 12, padding: "14px 10px", marginBottom: 14 }}>
              <div style={{ fontSize: 11, color: "#8888cc", marginBottom: 10, fontWeight: 600 }}>
                月相別 当選回数（直近20回）— タップで詳細
              </div>
              <PhaseBar stats={phaseStats} selected={selectedPhase} onSelect={setSelectedPhase} />
            </div>

            {selectedPhase !== null && (
              <div style={{ background: "#0d1a2a", border: "1px solid #4a90d9", borderRadius: 12, padding: 14, marginBottom: 14 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#4a90d9", marginBottom: 10 }}>
                  {PHASE_EMOJIS[selectedPhase]} {PHASE_LABELS[selectedPhase]} 期の頻出番号
                </div>
                <NumberGrid highlight={hotNums} />
                <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 5 }}>
                  {hotNums.map(n => (
                    <span key={n} style={{
                      background: "linear-gradient(135deg,#4a90d9,#2a60a9)",
                      borderRadius: 20, padding: "3px 10px", fontSize: 13, fontWeight: 700
                    }}>{n}</span>
                  ))}
                  {hotNums.length === 0 && <span style={{ color: "#6868a0", fontSize: 12 }}>データなし</span>}
                </div>
              </div>
            )}

            <div style={{ background: "#0d0d2a", border: "1px solid #2a2a5a", borderRadius: 12, padding: 14 }}>
              <div style={{ fontSize: 11, color: "#8888cc", marginBottom: 10, fontWeight: 600 }}>直近の当選番号 × 月齢</div>
              {enriched.slice(0, 8).map(d => (
                <div key={d.round} style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "7px 8px", background: "#070720", borderRadius: 8,
                  border: "1px solid #1a1a3a", marginBottom: 6
                }}>
                  <div style={{ width: 32, textAlign: "center", flexShrink: 0 }}>
                    <div style={{ fontSize: 15 }}>{PHASE_EMOJIS[d.phaseIndex]}</div>
                    <div style={{ fontSize: 9, color: "#6868a0" }}>{d.moonAge.toFixed(0)}</div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 10, color: "#6868a0", marginBottom: 2 }}>
                      第{d.round}回 {d.date}
                    </div>
                    <div style={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
                      {d.nums.map(n => (
                        <span key={n} style={{
                          background: "#1a2a4a", border: "1px solid #3a5a8a",
                          borderRadius: 4, padding: "1px 5px", fontSize: 12, fontWeight: 600
                        }}>{n}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* ── 予測タブ ── */}
        {activeTab === "predict" && (
          <>
            <div style={{ background: "#0d0d2a", border: "1px solid #2a2a5a", borderRadius: 12, padding: 14, marginBottom: 14 }}>
              <div style={{ fontSize: 11, color: "#8888cc", marginBottom: 8, fontWeight: 600 }}>対象抽選日を選択</div>
              <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <input type="date" value={targetDate}
                  onChange={e => { setTargetDate(e.target.value); setAiResult(null); }}
                  style={{
                    flex: 1, background: "#070720", border: "1px solid #3a3a6a",
                    color: "#e0e0f0", borderRadius: 8, padding: "8px 10px", fontSize: 14
                  }} />
                <div style={{ textAlign: "center", minWidth: 64 }}>
                  <div style={{ fontSize: 18 }}>{PHASE_EMOJIS[targetPhase]}</div>
                  <div style={{ fontSize: 10, color: "#8888cc" }}>{PHASE_LABELS[targetPhase]}</div>
                  <div style={{ fontSize: 9, color: "#6868a0" }}>月齢{targetMoonAge.toFixed(1)}</div>
                </div>
              </div>
            </div>

            <button onClick={runAI} disabled={loading} style={{
              width: "100%", padding: "14px 0", marginBottom: 14,
              background: loading ? "#1a1a3a" : "linear-gradient(135deg,#2a2a6a,#4a4aaa,#2a2a6a)",
              border: "1px solid #4a4aaa", borderRadius: 10,
              color: "#f0e6c8", fontSize: 15, fontWeight: 800,
              cursor: loading ? "not-allowed" : "pointer", letterSpacing: 1,
              boxShadow: loading ? "none" : "0 0 20px #4a4aaa44",
            }}>
              {loading ? "🌙 月齢データを分析中..." : "🔮 AI予測を実行する"}
            </button>

            {aiResult && !aiResult.error && (
              <>
                <div style={{
                  background: "linear-gradient(135deg,#0d0d2a,#1a1a3a)",
                  border: "1px solid #ffd700", borderRadius: 12, padding: 14, marginBottom: 10
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#ffd700" }}>🎯 AI予測番号</div>
                    <span style={{
                      background: (confColor[aiResult.confidence] || "#888") + "22",
                      border: `1px solid ${confColor[aiResult.confidence] || "#888"}`,
                      color: confColor[aiResult.confidence] || "#888",
                      borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700
                    }}>信頼度: {aiResult.confidence}</span>
                  </div>
                  <NumberGrid predicted={aiResult.predicted || []} />
                  <div style={{ marginTop: 10, display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "center" }}>
                    {(aiResult.predicted || []).map(n => (
                      <span key={n} style={{
                        background: "linear-gradient(135deg,#ffd700,#ff8c00)",
                        color: "#000", borderRadius: 50, width: 36, height: 36,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 14, fontWeight: 800, boxShadow: "0 0 10px #ffd70066"
                      }}>{n}</span>
                    ))}
                  </div>
                </div>

                <div style={{ background: "#0d0d2a", border: "1px solid #2a2a5a", borderRadius: 12, padding: 12, marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: "#4a90d9", fontWeight: 700, marginBottom: 5 }}>🌙 月相インサイト</div>
                  <div style={{ fontSize: 13, color: "#c0c0e0", lineHeight: 1.6 }}>{aiResult.moonInsight}</div>
                </div>

                <div style={{ background: "#0d0d2a", border: "1px solid #2a2a5a", borderRadius: 12, padding: 12, marginBottom: 10 }}>
                  <div style={{ fontSize: 11, color: "#8888cc", fontWeight: 700, marginBottom: 5 }}>📝 予測根拠</div>
                  <div style={{ fontSize: 13, color: "#c0c0e0", lineHeight: 1.6 }}>{aiResult.reason}</div>
                </div>

                <div style={{ padding: "8px 12px", background: "#0a0a1a", border: "1px solid #3a1a1a", borderRadius: 8, fontSize: 11, color: "#885555" }}>
                  ⚠️ これは統計的・娯楽的分析です。当選を保証するものではありません。
                </div>
              </>
            )}

            {aiResult?.error && (
              <div style={{ background: "#1a0a0a", border: "1px solid #8a2a2a", borderRadius: 10, padding: 14, color: "#ff8888", fontSize: 13 }}>
                ❌ {aiResult.error}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
